const db = require('../config/database');

exports.createProduct = async (req, res) => {
  try {
    const { title, description, price, category, stock } = req.body;
    const images = (req.files || []).map(f => '/uploads/' + f.filename);
    const imagesStr = JSON.stringify(images);
    
    const [result] = await db.query(
      'INSERT INTO products (title, description, price, category, stock, images) VALUES (?, ?, ?, ?, ?, ?)',
      [title, description, price, category, stock, imagesStr]
    );
    
    res.json({ id: result.insertId, title, description, price, category, stock, images });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const { title, description, price, category, stock } = req.body;
    await db.query(
      'UPDATE products SET title = ?, description = ?, price = ?, category = ?, stock = ? WHERE id = ?',
      [title, description, price, category, stock, req.params.id]
    );
    res.json({ message: 'Updated' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    await db.query('DELETE FROM products WHERE id = ?', [req.params.id]);
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getProduct = async (req, res) => {
  try {
    const [products] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
    if (products.length === 0) return res.status(404).json({ message: 'Not found' });
    
    const product = products[0];
    product.images = JSON.parse(product.images || '[]');
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getProducts = async (req, res) => {
  try {
    const { page = 1, limit = 12, category, q, sort } = req.query;
    let query = 'SELECT * FROM products WHERE 1=1';
    const params = [];
    
    if (category) {
      query += ' AND category = ?';
      params.push(category);
    }
    if (q) {
      query += ' AND title LIKE ?';
      params.push(`%${q}%`);
    }
    if (sort === 'price_asc') query += ' ORDER BY price ASC';
    if (sort === 'price_desc') query += ' ORDER BY price DESC';
    
    const offset = (page - 1) * limit;
    query += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit), offset);
    
    const [products] = await db.query(query, params);
    products.forEach(p => p.images = JSON.parse(p.images || '[]'));
    
    const [countResult] = await db.query('SELECT COUNT(*) as total FROM products');
    const total = countResult[0].total;
    
    res.json({ products, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
